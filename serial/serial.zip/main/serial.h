#ifndef SERIAL_H_
#define SERIAL_H_

#define MSG_BUFFER_LENGTH 256

void serial_out(const char *string);

#endif
