#ifndef COLLATZ_H
#define COLLATZ_H

#define APP_COLLATZ_ID 2

/*
 *  Computing task to be called once the network API is initialized
 */
void collatz_init(int root);

#endif
