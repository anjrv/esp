#ifndef UTILS_H_
#define UTILS_H_

int parse_int(char *str, int *ptr);
char *long_to_string(long x);
int bt_demo_available();

#endif
