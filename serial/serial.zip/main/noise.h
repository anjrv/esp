#ifndef NOISE_H_
#define NOISE_H_

void initialize_noise();
int random_int(int lim);
char *noise();

#endif
